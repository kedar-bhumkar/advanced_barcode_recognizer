document.addEventListener('DOMContentLoaded', () => {
    // DOM elements
    const imageUpload = document.getElementById('imageUpload');
    const preview = document.getElementById('preview');
    const scanCanvas = document.getElementById('scanCanvas');
    const status = document.getElementById('status');
    const result = document.getElementById('result');

    // Check if ZXing library is loaded
    if (typeof ZXing === 'undefined') {
        status.textContent = 'Error: ZXing library not loaded';
        result.textContent = 'Please check your internet connection and reload the page.';
        console.error('ZXing library not loaded');
        return;
    }

    // Initialize ZXing code reader and hints
    const codeReader = new ZXing.BrowserMultiFormatReader();
    const hints = new Map();
    const formats = [
        ZXing.BarcodeFormat.QR_CODE,
        ZXing.BarcodeFormat.DATA_MATRIX,
        ZXing.BarcodeFormat.AZTEC,
        ZXing.BarcodeFormat.PDF_417,
        ZXing.BarcodeFormat.EAN_13,
        ZXing.BarcodeFormat.EAN_8,
        ZXing.BarcodeFormat.UPC_A,
        ZXing.BarcodeFormat.UPC_E,
        ZXing.BarcodeFormat.CODE_128,
        ZXing.BarcodeFormat.CODE_39,
        ZXing.BarcodeFormat.CODE_93,
        ZXing.BarcodeFormat.ITF,
        ZXing.BarcodeFormat.CODABAR
    ];
    hints.set(ZXing.DecodeHintType.POSSIBLE_FORMATS, formats);
    hints.set(ZXing.DecodeHintType.TRY_HARDER, true);

    // Initialize the app
    function init() {
        status.textContent = 'Ready to scan barcodes. Upload an image.';
    }

    // Handle image upload
    imageUpload.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // Check if file is an image
        if (!file.type.match('image.*')) {
            status.textContent = 'Error: Not an image file';
            result.textContent = 'Please upload an image file (JPEG, PNG, etc.)';
            return;
        }

        // Display image preview
        const reader = new FileReader();
        reader.onload = (event) => {
            preview.src = event.target.result;
            preview.style.display = 'block';
            
            // Process the image with ZXing after it's loaded
            preview.onload = () => {
                processImage(preview);
            };
        };
        reader.onerror = () => {
            status.textContent = 'Error: Failed to read file';
            result.textContent = 'There was an error reading the file. Please try again.';
        };
        reader.readAsDataURL(file);
    });

    // Process image with ZXing
    async function processImage(imageElement) {
        status.textContent = 'Processing image...';
        result.textContent = '';

        try {
            // Get image dimensions
            const width = imageElement.naturalWidth;
            const height = imageElement.naturalHeight;

            // Set canvas dimensions to match image
            scanCanvas.width = width;
            scanCanvas.height = height;
            
            // Draw image on canvas
            const ctx = scanCanvas.getContext('2d');
            ctx.drawImage(imageElement, 0, 0, width, height);

            // Create a ZXing HTMLCanvasElementLuminanceSource
            const luminanceSource = new ZXing.HTMLCanvasElementLuminanceSource(scanCanvas);
            const binaryBitmap = new ZXing.BinaryBitmap(new ZXing.HybridBinarizer(luminanceSource));
            
            try {
                // Create a multi-format reader
                const reader = new ZXing.MultiFormatReader();
                reader.setHints(hints);
                
                // Try to decode the image using the binary bitmap
                const decodedResult = reader.decode(binaryBitmap);
                
                // Barcode detected successfully
                status.textContent = 'Barcode recognized successfully!';
                
                // Format the result
                const resultText = `Code: ${decodedResult.getText()}\nFormat: ${decodedResult.getBarcodeFormat()}`;
                document.getElementById('result').textContent = resultText;
                
                // Draw the barcode location on the canvas
                drawBarcodeLocation(ctx, decodedResult.getResultPoints());
                
            } catch (error) {
                // Try alternative method if the first one fails
                try {
                    // Use the BrowserMultiFormatReader as a fallback
                    const result = await codeReader.decodeFromImageUrl(imageElement.src);
                    
                    // Barcode detected successfully
                    status.textContent = 'Barcode recognized successfully!';
                    
                    // Format the result
                    const resultText = `Code: ${result.text}\nFormat: ${result.format}`;
                    document.getElementById('result').textContent = resultText;
                    
                    // Draw the barcode location on the canvas if available
                    if (result.resultPoints && result.resultPoints.length > 0) {
                        drawBarcodeLocation(ctx, result.resultPoints);
                    }
                    
                } catch (secondError) {
                    // Try one more approach with different binarizer
                    try {
                        const globalHistogramBinarizer = new ZXing.GlobalHistogramBinarizer(luminanceSource);
                        const secondBinaryBitmap = new ZXing.BinaryBitmap(globalHistogramBinarizer);
                        
                        const reader = new ZXing.MultiFormatReader();
                        reader.setHints(hints);
                        const thirdResult = reader.decode(secondBinaryBitmap);
                        
                        status.textContent = 'Barcode recognized successfully!';
                        const resultText = `Code: ${thirdResult.getText()}\nFormat: ${thirdResult.getBarcodeFormat()}`;
                        document.getElementById('result').textContent = resultText;
                        
                        drawBarcodeLocation(ctx, thirdResult.getResultPoints());
                    } catch (thirdError) {
                        // No barcode detected after all attempts
                        status.textContent = 'No barcode detected';
                        result.textContent = 'Could not detect a valid barcode in the image. Please try another image with a clearer barcode.';
                        console.error('ZXing errors:', error, secondError, thirdError);
                    }
                }
            }
        } catch (error) {
            // Handle any exceptions during processing
            status.textContent = 'Error processing image';
            result.textContent = error.message || 'An unexpected error occurred';
            console.error('Error in processImage:', error);
        }
    }

    // Draw barcode location on canvas
    function drawBarcodeLocation(ctx, points) {
        if (!points || points.length === 0) return;
        
        ctx.strokeStyle = 'rgba(255, 0, 0, 0.8)'; // Red color for detected barcodes
        ctx.lineWidth = 5;
        
        ctx.beginPath();
        
        // For QR codes and other 2D barcodes (usually 4 points)
        if (points.length >= 4) {
            ctx.moveTo(points[0].x, points[0].y);
            ctx.lineTo(points[1].x, points[1].y);
            ctx.lineTo(points[2].x, points[2].y);
            ctx.lineTo(points[3].x, points[3].y);
            ctx.lineTo(points[0].x, points[0].y);
        } 
        // For 1D barcodes (usually 2 points)
        else if (points.length >= 2) {
            // Calculate the corners of a rectangle for the barcode
            const p1 = points[0];
            const p2 = points[points.length - 1];
            
            // Calculate the width of the barcode (perpendicular to the line)
            const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
            const perpAngle = angle + Math.PI / 2;
            const width = 20; // Width of the barcode rectangle
            
            // Calculate the four corners of the rectangle
            const corners = [
                { x: p1.x - width * Math.cos(perpAngle), y: p1.y - width * Math.sin(perpAngle) },
                { x: p1.x + width * Math.cos(perpAngle), y: p1.y + width * Math.sin(perpAngle) },
                { x: p2.x + width * Math.cos(perpAngle), y: p2.y + width * Math.sin(perpAngle) },
                { x: p2.x - width * Math.cos(perpAngle), y: p2.y - width * Math.sin(perpAngle) }
            ];
            
            // Draw the rectangle
            ctx.moveTo(corners[0].x, corners[0].y);
            ctx.lineTo(corners[1].x, corners[1].y);
            ctx.lineTo(corners[2].x, corners[2].y);
            ctx.lineTo(corners[3].x, corners[3].y);
            ctx.lineTo(corners[0].x, corners[0].y);
        }
        
        ctx.stroke();
    }

    // Initialize the app
    init();
}); 